const AWS = require('aws-sdk');
const fs = require('fs');

AWS.config.update({
    region: "ap-southeast-1",
    endpoint: "http://localhost:8000"
});

const docClient = new AWS.DynamoDB.DocumentClient();

console.log("Importing Students into DynamoDB. Please wait.")

const students = JSON.parse(fs.readFileSync('student.json', 'utf-8'));

students.forEach(function (student) {
    console.log(student);
    var params = {
        TableName: "student",
        Item: {
            id: student.id,
            ma_sinhvien: student.ma_sinhvien,
            ten_sinhvien: student.ten_sinhvien,
            namsinh: student.namsinh,
            ma_lop: student.ma_lop,
            avatar: student.avatar
        }
    };
    docClient.put(params, function (err, data){
       if(err){
           console.error("Unable to add student", student.ten_sinhvien, ". Error JSON:", JSON.stringify(err, null, 2))
       } else {
           console.log("PutItem succeeded: ", student.ten_sinhvien);
       }
    });

})

