const AWS = require('aws-sdk');
const fs = require('fs');
const path = require('path');
const jimp = require('jimp');

AWS.config.update({
    region: "ap-southeast-1",
    accessKeyId: "AKIASQ7E75LEFIZXWZ4T",
    secretAccessKey: "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",
    /*    endpoint: "http://localhost:8000"*/
    /*    endpoint: process.env.ENDPOINT,*/
});

let docClient = new AWS.DynamoDB.DocumentClient();
let s3 = new AWS.S3({apiVersion: '2006-03-01'})

function getAllItem(res) {
    let params = {
        TableName: "student"
    }

    docClient.scan(params, ((err, data) => {
        if (err) {
            console.log('err: ', err);
        } else {
            let student = [];
            data.Items.forEach((item, index) => {
                student.push(item);
            });
            student.sort((a, b) => {
                let x = a.ten_sinhvien.toLowerCase();
                let y = b.ten_sinhvien.toLowerCase();
                if (x > y) {
                    return 1;
                }
                if (y > x) {
                    return -1;
                }
            })
            res.render('listStudents', {
                students: student,
                size: student.length
            })
        }
    }))
}

function createItem(id, ma_sinhvien, ten_sinhvien, namsinh, ma_lop, avatar, res) {
    let params = {
        TableName: "student",
        Item: {
            id: String(id),
            ma_sinhvien: ma_sinhvien,
            ten_sinhvien: ten_sinhvien,
            namsinh: namsinh,
            ma_lop: ma_lop,
            avatar: avatar,
        }
    }
    docClient.put(params, ((err, data) => {
        if (err) {
            console.log('err : ', err);
        } else {
        }
    }))
}

function updateItem(id, ma_sinhvien, ten_sinhvien, namsinh, ma_lop, res, status) {
    let params = {
        TableName: "student",
        Key: {
            id: String(id),
        },
        UpdateExpression: "set ma_sinhvien = :ma_sinhvien, ten_sinhvien = :ten_sinhvien, namsinh = :namsinh, ma_lop = :ma_lop",
        ExpressionAttributeValues: {
            ':ma_sinhvien': String(ma_sinhvien),
            ':ten_sinhvien': String(ten_sinhvien),
            ':namsinh': String(namsinh),
            ':ma_lop': String(ma_lop)
        },
    };
    docClient.update(params, ((err, data) => {
        if (err) {
            console.log('err', err);
        } else {
            if(status === 0){
                res.redirect('/students');
            }
        }
    }))
}

function findItem(id, res) {
    let params = {
        TableName: 'student',
        KeyConditionExpression: "#id = :id",
        ExpressionAttributeNames: {
            "#id": "id"
        },
        ExpressionAttributeValues: {
            ":id": String(id)
        }
    }
    docClient.query(params, (err, data) => {
        if (err) {
            res.end(JSON.stringify({
                error: 'Lỗi không thể tìm thấy Item : ', id,
            }))
        } else {
            let student = data.Items.pop();
            res.render('informationStudent', {
                student: student
            })
        }
    })
}

function deleteItem(id, res) {
    let params = {
        TableName: 'student',
        Key: {
            id: String(id)
        }
    }
    docClient.delete(params, ((err, data) => {
        if (err) {
            console.log('err : ', err);
        } else {
            res.redirect('/students')
        }
    }))
}

function uploadImageToS3(id, file, res) {
    let params = {
        ACL: "public-read",
        Bucket: process.env.S3_BUCKET,
        Key: '',
        Body: '',
    };

    fs.readFile(file.path, ((err, data) => {
        params.Body = data;
        params.Key = file.originalname;

        s3.upload(params, (err, data) => {
            if (err) {
                console.log('err: s3 upload : ', err);
            } else {
                console.log('s3 upload success ', data.Location);
                setAvatarForStudent(id, data.Location, res);
            }
        })
    }))


}

function setAvatarForStudent(id, avatar, res) {
    let params = {
        TableName: "student",
        Key: {
            id: String(id),
        },
        UpdateExpression: "set avatar = :avatar",
        ExpressionAttributeValues: {
            ':avatar': String(avatar),
        }
    }
    docClient.update(params, ((err, data) => {
        if (err) {
            console.log('err : ', err);
        } else {
            res.redirect('/students');
        }
    }))
}

module.exports = {
    getAllItem: getAllItem,
    createItem: createItem,
    updateItem: updateItem,
    deleteItem: deleteItem,
    findItem: findItem,
    uploadImageToS3: uploadImageToS3
}
