const express = require('express');
const router = express.Router();
const Data = require('./aws');
const fs = require('fs');
const multer = require('multer');

let storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/image/upload');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
})


router.get('', (req, res) => {
    res.render('index');
})

router.get('/students', (req, res) => {
    Data.getAllItem(res);
})

router.get('/students/:id', ((req, res) => {
    let id = req.params.id;
    Data.findItem(id, res);
}))

router.get('/add-student', (req, res) => {
    res.render('addStudent');
})

const upload = multer({storage: storage});
router.post('/add-student', upload.single('file'), (req, res) => {
    let id = req.body.id;
    let ma_sinhvien = req.body.ma_sinhvien;
    let ten_sinhvien = req.body.ten_sinhvien;
    let namsinh = req.body.namsinh;
    let ma_lop = req.body.ma_lop;

    let file = req.file;


    Data.createItem(id, ma_sinhvien, ten_sinhvien, namsinh, ma_lop, '', res);
    Data.uploadImageToS3(id, file, res);
})

router.post('/students/:id', upload.single('avatar'), (req, res) => {
    let id = req.params.id;
    let ma_sinhvien = req.body.ma_sinhvien;
    let ten_sinhvien = req.body.ten_sinhvien;
    let namsinh = req.body.namsinh;
    let ma_lop = req.body.ma_lop;

    let file = req.file;

    if(typeof file === 'undefined'){
        Data.updateItem(id, ma_sinhvien, ten_sinhvien, namsinh, ma_lop, res, 0);
    } else {
        Data.updateItem(id, ma_sinhvien, ten_sinhvien, namsinh, ma_lop, res, 1);
        Data.uploadImageToS3(id, file, res);
    }
})

router.get('/deleteItem/:id', (req, res) => {
    let id = req.params.id;
    Data.deleteItem(id, res);
})


module.exports = router;
